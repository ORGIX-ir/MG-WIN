using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Net.NetworkInformation;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Win32;
using MGWin.Core;
using MGWin.Network;

namespace MGWin;

public partial class MainWindow : Window
{
    private const int HistoryLimit = 60;
    private const int LossWindow = 20;
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(1) };
    private readonly Queue<long?> _latencyHistory = new();
    private readonly Queue<bool> _pingHistory = new();
    private readonly ObservableCollection<string> _diagnosticLog = new();
    private readonly CancellationTokenSource _lifetime = new();
    private string? _selectedAdapterId;
    private string _currentGateway = "—";
    private string? _lastSnapshotError;
    private string? _lastAdapterName;
    private long _previousReceived;
    private long _previousSent;
    private DateTime _previousCounterTime;
    private bool _hasPreviousCounters;
    private bool _pingInFlight;
    private bool _diagnosticInFlight;
    private bool _isClosing;
    private int _ticks;
    private NetworkAvailabilityChangedEventHandler? _availabilityHandler;

    public MainWindow()
    {
        InitializeComponent();
        _timer.Tick += Timer_Tick;
        DiagnosticLogList.ItemsSource = _diagnosticLog;
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        RefreshAdapterList();
        UpdateSnapshot();
        AddLog("پایش محلی شروع شد.");
        AddLog("برای سنجش دسترسی عمومی از ICMP به مقصد ثابت 1.1.1.1 استفاده می‌شود.");

        _availabilityHandler = (_, args) =>
        {
            _ = Dispatcher.InvokeAsync(() =>
            {
                if (_isClosing) return;
                AddLog(args.IsAvailable
                    ? "ویندوز دسترسی شبکه را در یکی از رابط‌ها فعال گزارش کرد."
                    : "ویندوز قطع‌شدن دسترسی شبکه را گزارش کرد.");
                UpdateSnapshot();
            });
        };
        NetworkChange.NetworkAvailabilityChanged += _availabilityHandler;

        ((System.Windows.Media.Animation.Storyboard)FindResource("HaloPulse")).Begin(this, true);
        AnimatePage(DashboardView);
        _timer.Start();
        await RunPingAsync();
    }

    private void Window_Closing(object? sender, CancelEventArgs e)
    {
        _isClosing = true;
        _timer.Stop();
        _lifetime.Cancel();
        if (_availabilityHandler is not null)
        {
            NetworkChange.NetworkAvailabilityChanged -= _availabilityHandler;
        }
    }

    private async void Timer_Tick(object? sender, EventArgs e)
    {
        if (_isClosing) return;

        UpdateSnapshot();
        _ticks++;
        if (_ticks % 2 == 0)
        {
            await RunPingAsync();
        }
    }

    private void UpdateSnapshot()
    {
        if (_isClosing) return;
        try
        {
            var snapshot = NetworkMonitor.ReadSnapshot(_selectedAdapterId);
            if (!string.Equals(_lastAdapterName, snapshot.AdapterName, StringComparison.Ordinal))
            {
                _hasPreviousCounters = false;
                _lastAdapterName = snapshot.AdapterName;
            }

            var now = DateTime.UtcNow;
            var elapsed = _hasPreviousCounters
                ? Math.Max(0.1, (now - _previousCounterTime).TotalSeconds)
                : 1.0;

            var receivedRate = _hasPreviousCounters && snapshot.ReceivedBytes >= _previousReceived
                ? (snapshot.ReceivedBytes - _previousReceived) / elapsed
                : 0d;
            var sentRate = _hasPreviousCounters && snapshot.SentBytes >= _previousSent
                ? (snapshot.SentBytes - _previousSent) / elapsed
                : 0d;

            _previousReceived = snapshot.ReceivedBytes;
            _previousSent = snapshot.SentBytes;
            _previousCounterTime = now;
            _hasPreviousCounters = snapshot.AdapterName != "بدون Ethernet یا Wi-Fi فعال";

            _currentGateway = snapshot.Gateway;
            var selectedAdapter = snapshot.Adapters.FirstOrDefault(x => x.Name == snapshot.AdapterName && x.CanMeasureBandwidth)
                                  ?? snapshot.Adapters.FirstOrDefault(x => x.Id == _selectedAdapterId && x.CanMeasureBandwidth);

            if (selectedAdapter is not null && !string.Equals(_selectedAdapterId, selectedAdapter.Id, StringComparison.Ordinal))
            {
                _selectedAdapterId = selectedAdapter.Id;
                _hasPreviousCounters = false;
            }

            AdapterShortNameText.Text = snapshot.AdapterName;
            var linkSpeed = selectedAdapter is null
                ? string.Empty
                : $"  ·  {NetworkMonitor.FormatLinkSpeed(selectedAdapter.SpeedBitsPerSecond)}";
            AdapterIpText.Text = $"IP: {snapshot.IPv4}{linkSpeed}";
            OnlineStateText.Text = snapshot.IsNetworkAvailable ? "شبکه محلی در دسترس" : "شبکه محلی قطع است";
            OnlineDot.Fill = snapshot.IsNetworkAvailable
                ? new SolidColorBrush(Color.FromRgb(85, 214, 165))
                : new SolidColorBrush(Color.FromRgb(245, 104, 118));
            DownloadRateText.Text = (receivedRate / (1024 * 1024)).ToString("0.00", CultureInfo.InvariantCulture);
            UploadRateText.Text = (sentRate / (1024 * 1024)).ToString("0.00", CultureInfo.InvariantCulture);
            TotalsText.Text = $"RX {NetworkMonitor.FormatBytes(snapshot.ReceivedBytes)}   ·   TX {NetworkMonitor.FormatBytes(snapshot.SentBytes)}";
            _lastSnapshotError = null;
        }
        catch (Exception ex) when (ex is NetworkInformationException or InvalidOperationException or System.Net.Sockets.SocketException)
        {
            if (_lastSnapshotError != ex.Message)
            {
                AddLog($"خواندن وضعیت شبکه با خطا روبه‌رو شد: {ex.Message}");
                _lastSnapshotError = ex.Message;
            }
        }
    }

    private async Task RunPingAsync()
    {
        if (_pingInFlight || _isClosing) return;
        _pingInFlight = true;
        try
        {
            var sample = await NetworkMonitor.ProbeAsync(_lifetime.Token);
            if (_isClosing) return;

            _latencyHistory.Enqueue(sample.Success ? sample.RoundtripMilliseconds : null);
            while (_latencyHistory.Count > HistoryLimit) _latencyHistory.Dequeue();
            _pingHistory.Enqueue(sample.Success);
            while (_pingHistory.Count > LossWindow) _pingHistory.Dequeue();

            UpdateMetrics();
            LastUpdateText.Text = DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture);
            ChartSummaryText.Text = sample.Success
                ? $"پاسخ {sample.RoundtripMilliseconds} میلی‌ثانیه"
                : $"بدون پاسخ · {sample.Message}";
            DrawLatencyChart();
        }
        catch (OperationCanceledException)
        {
            // Normal when the window is closed while an ICMP request is pending.
        }
        finally
        {
            _pingInFlight = false;
        }
    }

    private void UpdateMetrics()
    {
        var metrics = NetworkQualityCalculator.Calculate(_latencyHistory.ToArray(), _pingHistory.ToArray());
        PingValueText.Text = metrics.LatestLatencyMilliseconds?.ToString(CultureInfo.InvariantCulture) ?? "—";
        JitterValueText.Text = metrics.AverageJitterMilliseconds?.ToString("0.0", CultureInfo.InvariantCulture) ?? "—";
        LossValueText.Text = metrics.PacketLossPercent?.ToString("0.#", CultureInfo.InvariantCulture) ?? "—";
        HealthScoreText.Text = _pingHistory.Count == 0 ? "—" : metrics.HealthScore.ToString(CultureInfo.InvariantCulture);
        HealthLabelText.Text = metrics.StatusLabel;
    }

    private void DrawLatencyChart()
    {
        if (LatencyCanvas.ActualWidth < 10 || LatencyCanvas.ActualHeight < 10) return;
        LatencyCanvas.Children.Clear();
        var samples = _latencyHistory.ToArray();
        if (samples.Length == 0) return;

        var valid = samples.Where(x => x.HasValue).Select(x => x!.Value).ToArray();
        if (valid.Length == 0) return;

        var maxValue = Math.Max(100d, valid.Max() * 1.25d);
        var width = LatencyCanvas.ActualWidth;
        var height = LatencyCanvas.ActualHeight;
        LatencyCanvas.Children.Add(new Polyline
        {
            Points = new PointCollection { new(0, height - 2), new(width, height - 2) },
            Stroke = new SolidColorBrush(Color.FromArgb(60, 130, 116, 190)),
            StrokeThickness = 1
        });

        var segment = new List<System.Windows.Point>();
        System.Windows.Point? lastPoint = null;
        for (var i = 0; i < samples.Length; i++)
        {
            if (samples[i] is not long latency)
            {
                DrawSegment(segment);
                segment.Clear();
                continue;
            }

            var x = samples.Length == 1 ? width / 2 : width * i / (samples.Length - 1);
            var y = height - (Math.Clamp(latency / maxValue, 0d, 1d) * (height - 12)) - 5;
            var point = new System.Windows.Point(x, y);
            segment.Add(point);
            lastPoint = point;
        }
        DrawSegment(segment);

        if (lastPoint is { } last)
        {
            var marker = new Ellipse
            {
                Width = 8,
                Height = 8,
                Fill = Brushes.White,
                Stroke = new SolidColorBrush(Color.FromRgb(150, 124, 244)),
                StrokeThickness = 2
            };
            Canvas.SetLeft(marker, last.X - 4);
            Canvas.SetTop(marker, last.Y - 4);
            LatencyCanvas.Children.Add(marker);
        }

        void DrawSegment(IReadOnlyCollection<System.Windows.Point> points)
        {
            if (points.Count < 2) return;
            LatencyCanvas.Children.Add(new Polyline
            {
                Points = new PointCollection(points),
                Stroke = new LinearGradientBrush(Color.FromRgb(177, 151, 255), Color.FromRgb(91, 220, 202), 0),
                StrokeThickness = 2.5,
                StrokeLineJoin = PenLineJoin.Round,
                StrokeStartLineCap = PenLineCap.Round,
                StrokeEndLineCap = PenLineCap.Round
            });
        }
    }

    private void LatencyCanvas_SizeChanged(object sender, SizeChangedEventArgs e) => DrawLatencyChart();

    private void RefreshAdapterList()
    {
        var snapshot = NetworkMonitor.ReadSnapshot(_selectedAdapterId);
        AdapterList.ItemsSource = snapshot.Adapters
            .OrderByDescending(x => x.Status == "فعال" && x.CanMeasureBandwidth)
            .ThenBy(x => x.Name)
            .ToList();

        var selected = snapshot.Adapters.FirstOrDefault(x => x.Name == snapshot.AdapterName && x.CanMeasureBandwidth)
                       ?? snapshot.Adapters.FirstOrDefault(x => x.Id == _selectedAdapterId && x.CanMeasureBandwidth);
        if (selected is not null)
        {
            AdapterList.SelectedItem = selected;
        }

        AdapterListHint.Text = $"{snapshot.Adapters.Count} آداپتر شناسایی شد. فقط Ethernet و Wi-Fi در سنجش مصرف انتخاب‌پذیر هستند.";
    }

    private void AdapterList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (AdapterList.SelectedItem is not AdapterInfo adapter) return;
        if (!adapter.CanMeasureBandwidth)
        {
            AddLog($"{adapter.Name} فقط برای مشاهده است و در محاسبه مصرف انتخاب نمی‌شود.");
            AdapterList.SelectedItem = AdapterList.Items.Cast<AdapterInfo>()
                .FirstOrDefault(x => string.Equals(x.Id, _selectedAdapterId, StringComparison.Ordinal));
            return;
        }

        _selectedAdapterId = adapter.Id;
        _hasPreviousCounters = false;
        UpdateSnapshot();
        AddLog($"آداپتر سنجش مصرف انتخاب شد: {adapter.Name}");
    }

    private async void RunDiagnostic_Click(object sender, RoutedEventArgs e)
    {
        if (_diagnosticInFlight || _isClosing) return;
        _diagnosticInFlight = true;
        RunDiagnosticButton.IsEnabled = false;
        AddLog("آزمایش دسترسی آغاز شد؛ ابتدا دروازه محلی و سپس مقصد عمومی بررسی می‌شود.");
        try
        {
            if (_currentGateway != "—")
            {
                var gatewayResult = await NetworkMonitor.ProbeGatewayAsync(_currentGateway, _lifetime.Token);
                if (_isClosing) return;
                AddLog(gatewayResult.Success
                    ? $"دروازه محلی ({_currentGateway}): پاسخ در {gatewayResult.RoundtripMilliseconds} ms"
                    : $"دروازه محلی ({_currentGateway}): {gatewayResult.Message}");
            }
            else
            {
                AddLog("دروازه پیش‌فرض IPv4 برای آزمایش محلی پیدا نشد.");
            }

            var publicResult = await NetworkMonitor.ProbeAsync(_lifetime.Token);
            if (_isClosing) return;
            AddLog(publicResult.Success
                ? $"مقصد عمومی 1.1.1.1: موفق؛ {publicResult.RoundtripMilliseconds} ms"
                : $"مقصد عمومی 1.1.1.1: ناموفق؛ {publicResult.Message}");
        }
        catch (OperationCanceledException)
        {
            // Expected if the user closes the app during a diagnostic.
        }
        finally
        {
            _diagnosticInFlight = false;
            if (!_isClosing) RunDiagnosticButton.IsEnabled = true;
        }
    }

    private void RefreshAdapters_Click(object sender, RoutedEventArgs e)
    {
        RefreshAdapterList();
        UpdateSnapshot();
        AddLog("فهرست آداپترها بروزرسانی شد.");
    }

    private async void ManualPing_Click(object sender, RoutedEventArgs e)
    {
        await RunPingAsync();
    }

    private void ToggleMonitoring_Click(object sender, RoutedEventArgs e)
    {
        if (_timer.IsEnabled)
        {
            _timer.Stop();
            PauseMonitoringButton.Content = "ادامه پایش";
            AddLog("پایش زنده موقتاً متوقف شد؛ داده‌های قبلی حفظ شدند.");
        }
        else
        {
            _timer.Start();
            PauseMonitoringButton.Content = "توقف پایش";
            UpdateSnapshot();
            AddLog("پایش زنده ادامه پیدا کرد.");
        }
    }

    private void ExportLog_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new SaveFileDialog
        {
            Title = "ذخیره گزارش MG-WIN",
            FileName = $"MG-WIN-diagnostics-{DateTime.Now:yyyyMMdd-HHmmss}.csv",
            Filter = "CSV file (*.csv)|*.csv",
            DefaultExt = ".csv",
            AddExtension = true
        };
        if (dialog.ShowDialog(this) != true) return;

        try
        {
            var builder = new StringBuilder();
            builder.AppendLine("time,entry");
            foreach (var line in _diagnosticLog.Reverse())
            {
                var split = line.Split(new[] { "  ·  " }, 2, StringSplitOptions.None);
                var time = split.Length > 0 ? split[0] : string.Empty;
                var message = split.Length > 1 ? split[1] : line;
                builder.Append(Csv(time)).Append(',').AppendLine(Csv(message));
            }

            File.WriteAllText(dialog.FileName, builder.ToString(), new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
            AddLog($"گزارش در مسیر انتخاب‌شده ذخیره شد: {dialog.FileName}");
            MessageBox.Show(this, "گزارش با موفقیت ذخیره شد.", "MG-WIN", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            MessageBox.Show(this, $"ذخیره گزارش انجام نشد: {ex.Message}", "خطا", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private static string Csv(string value) => $"\"{value.Replace("\"", "\"\"")}\"";

    private void AddLog(string message)
    {
        _diagnosticLog.Insert(0, $"{DateTime.Now:HH:mm:ss}  ·  {message}");
        while (_diagnosticLog.Count > 100) _diagnosticLog.RemoveAt(_diagnosticLog.Count - 1);
    }

    private void ShowPage(string page)
    {
        DashboardView.Visibility = page == "dashboard" ? Visibility.Visible : Visibility.Collapsed;
        AdaptersView.Visibility = page == "adapters" ? Visibility.Visible : Visibility.Collapsed;
        DiagnosticsView.Visibility = page == "diagnostics" ? Visibility.Visible : Visibility.Collapsed;

        DashboardNav.Background = page == "dashboard" ? new SolidColorBrush(Color.FromRgb(36, 29, 69)) : Brushes.Transparent;
        AdaptersNav.Background = page == "adapters" ? new SolidColorBrush(Color.FromRgb(36, 29, 69)) : Brushes.Transparent;
        DiagnosticsNav.Background = page == "diagnostics" ? new SolidColorBrush(Color.FromRgb(36, 29, 69)) : Brushes.Transparent;
        DashboardNav.Foreground = page == "dashboard" ? new SolidColorBrush(Color.FromRgb(199, 181, 255)) : new SolidColorBrush(Color.FromRgb(146, 155, 180));
        AdaptersNav.Foreground = page == "adapters" ? new SolidColorBrush(Color.FromRgb(199, 181, 255)) : new SolidColorBrush(Color.FromRgb(146, 155, 180));
        DiagnosticsNav.Foreground = page == "diagnostics" ? new SolidColorBrush(Color.FromRgb(199, 181, 255)) : new SolidColorBrush(Color.FromRgb(146, 155, 180));

        var activeView = page switch
        {
            "adapters" => AdaptersView,
            "diagnostics" => DiagnosticsView,
            _ => DashboardView
        };
        AnimatePage(activeView);
        if (page == "adapters") RefreshAdapterList();
    }

    private static void AnimatePage(Grid page)
    {
        page.Opacity = 0;
        var slide = new TranslateTransform(0, 8);
        page.RenderTransform = slide;
        var ease = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut };
        page.BeginAnimation(OpacityProperty, new System.Windows.Media.Animation.DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(320)) { EasingFunction = ease });
        slide.BeginAnimation(TranslateTransform.YProperty, new System.Windows.Media.Animation.DoubleAnimation(8, 0, TimeSpan.FromMilliseconds(320)) { EasingFunction = ease });
    }

    private void DashboardNav_Click(object sender, RoutedEventArgs e) => ShowPage("dashboard");
    private void AdaptersNav_Click(object sender, RoutedEventArgs e) => ShowPage("adapters");
    private void DiagnosticsNav_Click(object sender, RoutedEventArgs e) => ShowPage("diagnostics");

    private void TopBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed) DragMove();
    }

    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void Close_Click(object sender, RoutedEventArgs e) => Close();
}
